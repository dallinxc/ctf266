#!/usr/bin/env python3
"""
CAPEC-28 Fuzzing CTF - Vulnerable Application
Find the hidden flag by fuzzing the input!
"""

import sys

FLAG = "FLAG{fuzz_th3_inputs_4_pr0fit}"

def process_input(user_input):
    # Normal inputs get normal responses
    if len(user_input) == 0:
        return "Error: Empty input."
    
    if len(user_input) > 256:
        # Buffer overflow - app "crashes" and leaks part of the flag
        print("[CRASH] Segmentation fault - buffer overflow detected!")
        print(f"Memory dump: {FLAG[:15]}...")
        sys.exit(1)

    if "'" in user_input or '"' in user_input:
        print("[WARNING] Special character detected in input.")
        return "Input rejected."

    if "%n" in user_input or "%x" in user_input:
        # Format string vulnerability leaks the flag
        print("[CRASH] Format string vulnerability triggered!")
        print(f"Stack dump: {FLAG}")
        sys.exit(1)

    if "\x00" in user_input:
        print("[CRASH] Null byte injection detected!")
        print(f"Debug output: {FLAG[15:]}")
        sys.exit(1)

    if user_input.isdigit():
        val = int(user_input)
        if val < 0 or val > 9999:
            print("[ERROR] Integer overflow!")
            return "Value out of range."
        return f"Processed value: {val * 2}"

    return f"Hello, {user_input}! Welcome to the system."


def main():
    print("=" * 50)
    print("  Welcome to FuzzMe Corp Employee Portal v1.0")
    print("  Enter your employee ID or name below.")
    print("=" * 50)
    
    while True:
        try:
            user_input = input("\n> Enter input: ")
            if user_input.lower() == "exit":
                print("Goodbye!")
                break
            result = process_input(user_input)
            print(result)
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break


if __name__ == "__main__":
    main()
