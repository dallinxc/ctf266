# CAPEC-28: Fuzzing for Fun and Flags 🐛

## Overview
This CTF demonstrates **CAPEC-28 (Fuzzing for Exploitable Vulnerabilities)**. You are given a "corporate employee portal" application that accepts user input. Your goal is to **fuzz the input** — sending unexpected, malformed, or boundary-case data — to crash the application and reveal the hidden flag.

## Setup
1. Make sure you have **Python 3** installed.
2. Clone this repo and run:
   ```bash
   python3 vulnerable_app.py
   ```
3. The app will prompt you for input. Start fuzzing!

## Objective
Find the full flag in the format: `FLAG{...}`

The application has multiple vulnerabilities. You may need to trigger more than one crash to piece together the complete flag — or find the one input that dumps it all at once.

## Rules
- No reading the source code! Treat `vulnerable_app.py` as a black box.
- Use manual fuzzing or write your own fuzzing script.
- The flag is one continuous string.

## Hints
- **Hint 1:** What happens when you send something the program wasn't designed to handle — like format string specifiers?
- **Hint 2:** Try sending a LOT of data. What does the app do when it can't handle the size?

## CTF Type
**Reverse Engineering / Exploitation** — Fuzz a local application to discover and trigger vulnerabilities that leak the flag.

## About CAPEC-28
CAPEC-28 describes an attack where an adversary sends random or malformed data to an application's inputs, observing crashes and error messages that reveal exploitable weaknesses. Learn more: [CAPEC-28](https://capec.mitre.org/data/definitions/28.html)
